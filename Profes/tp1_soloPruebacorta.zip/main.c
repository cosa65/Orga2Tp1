#include "lista.h"
#include <stdio.h>

int main(void) {
	// COMPLETAR AQUI EL CODIGO
    return 0;
}

